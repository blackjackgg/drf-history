track_actions = (
    ("POST", "POST"),
    ("DELETE", "DELETE"),
    ("PUT", "PUT"),
    ("PATCH", "PATCH"),
)
TABLES = ["track_actions_history", "django_admin_log"]
